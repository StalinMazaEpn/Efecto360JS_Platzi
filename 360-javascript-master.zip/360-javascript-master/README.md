# 360 JavaScript
- StockX 360 effect in vanilla JavaScript
- Watch the free class in Youtube 👉 https://youtu.be/2hVl03F8qdo
![StockX 360 360 effect](https://repository-images.githubusercontent.com/237585410/394a1f00-449b-11ea-98a9-c84d1c13f90a)
